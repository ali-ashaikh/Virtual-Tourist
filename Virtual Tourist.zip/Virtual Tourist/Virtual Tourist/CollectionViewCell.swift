//
//  CollectionViewCell.swift
//  Virtual Tourist
//
//  Created by Ali Ashaikh on 2019-02-16.
//  Copyright © 2019 Ali Ashaikh. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var picture: UIImageView!
    
    
    
}
